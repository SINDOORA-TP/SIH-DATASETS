MINE MONITORING DATASET PACK
=============================

This package contains TWO SEPARATE prototype datasets for the website:

1) InSAR_Datasets/
   - insar_deformation_timeseries_SYNTHETIC.csv
   - insar_latest_points_SYNTHETIC.csv

   Purpose:
   - Map visualization
   - deformation time series
   - velocity/coherence display

2) XGBoost_Datasets/
   - xgboost_full_SYNTHETIC.csv
   - xgboost_train_SYNTHETIC.csv
   - xgboost_validation_SYNTHETIC.csv
   - xgboost_test_SYNTHETIC.csv

   Purpose:
   - XGBoost prototype training and risk classification

IMPORTANT:
These CSVs are SYNTHETIC prototype data generated for development/testing.
They are NOT real mine-site measurements and must not be presented as
real observations.

PUBLIC REAL-DATA SOURCES IDENTIFIED FOR FUTURE REPLACEMENT:
- EGMS calibrated InSAR time-series data (Athens/Thessaly example):
  https://github.com/chrisZerv/insar-deformation-encodings
- Virginia Tech InSAR deformation hotspot dataset:
  https://github.com/ashutoshtiwari996/insar_deformation_hotspots
- Hunchun coal-mine InSAR deformation dataset:
  https://zenodo.org/records/14864957
- InSAR + XGBoost slope-unit prediction dataset/code:
  https://zenodo.org/records/16340859

The real datasets above have different formats and study areas; they should
not be merged blindly. A preprocessing step is required before using them
in the website/model.
