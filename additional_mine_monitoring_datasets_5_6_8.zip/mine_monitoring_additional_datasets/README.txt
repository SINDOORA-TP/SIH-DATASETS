ADDITIONAL DATASETS FOR MINE MONITORING WEBSITE

5_Surface_Sensor_Data
---------------------
surface_sensor_data_SYNTHETIC.csv
Contains prototype time-series telemetry for tilt, vibration, soil moisture,
surface displacement, crack width, battery and signal strength.

6_Mine_Boundary_Data
--------------------
mine_boundary_SYNTHETIC.geojson
GeoJSON polygon for displaying the monitored area on a web map.
mine_zones_SYNTHETIC.csv
Simple zone metadata for dashboard/map labels.

8_Weather_Data
--------------
weather_data_SYNTHETIC.csv
Contains prototype hourly temperature, humidity, rainfall, wind and pressure.

IMPORTANT
----------
All files in this package are SYNTHETIC prototype data generated for website
development/testing. They are not measurements from a real mine.

For a real deployment, sensor data should come from field devices and the
boundary should come from the actual mine GIS/survey source.

A real published multi-sensor landslide dataset contains soil moisture,
vibration and inclination readings, and can be used as a methodological
reference for the sensor schema:
https://data.mendeley.com/datasets/9w43sg73bt/1
